import java.awt.*;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.*;

public class Server {
    private static final int PORT = 5555;
    private static Connection conn;
    private static JLabel statusLabel;
    private static JProgressBar progressBar;
    private static final int MAX_CLICKS = 5;

    // Lista de jugadores con su nombre y mejor tiempo
    private static ArrayList<Jugador> ranking = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("Servidor iniciado...");

        // Conexión a la base de datos MySQL
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/juego_autenticacion", "root", "1234");
            System.out.println("Conexión exitosa a la base de datos.");
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        // Configuración de la interfaz gráfica del servidor
        JFrame frame = new JFrame("Servidor de Juego");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null); // Centrar la ventana
        frame.setLayout(null); // Usar Layout nulo para el posicionamiento manual de los componentes
        frame.getContentPane().setBackground(Color.DARK_GRAY); // Fondo oscuro

        // Configuración del JLabel de estado
        statusLabel = new JLabel("Esperando clientes...", SwingConstants.CENTER);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 20));
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setOpaque(true);
        statusLabel.setBackground(Color.BLACK);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Espaciado
        statusLabel.setBounds(0, 0, 600, 50); // Ajuste en la posición
        frame.add(statusLabel);

        // Barra de progreso (global, pero se actualizará individualmente por cliente)
        progressBar = new JProgressBar(0, MAX_CLICKS);
        progressBar.setStringPainted(true);
        progressBar.setValue(0);
        progressBar.setFont(new Font("Arial", Font.PLAIN, 16));
        progressBar.setForeground(Color.GREEN);
        progressBar.setBackground(Color.LIGHT_GRAY);
        progressBar.setBounds(50, 80, 500, 30); // Posición y tamaño de la barra
        frame.add(progressBar);

        frame.setVisible(true);

        // Iniciar el servidor para aceptar clientes
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Esperando cliente...");
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Cliente conectado: " + socket.getRemoteSocketAddress());

                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                String username = in.readLine();
                String password = in.readLine();

                if (authenticateUser(username, password)) {
                    SwingUtilities.invokeLater(() -> statusLabel.setText("Usuario conectado: " + username));
                    out.println("Autenticación exitosa.");
                    out.println("¡Juego comenzado!");
                    new ClientHandler(socket, out, in, username, frame).start();
                } else {
                    out.println("Autenticación fallida. Cerrando conexión.");
                    socket.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean authenticateUser(String username, String password) {
        try {
            String query = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
            try (PreparedStatement pst = conn.prepareStatement(query)) {
                pst.setString(1, username);
                pst.setString(2, password);
                try (ResultSet rs = pst.executeQuery()) {
                    return rs.next();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private static void updateBestTime(String username, long duration) {
        String query = "UPDATE usuarios SET mejor_tiempo = ? WHERE username = ? AND (mejor_tiempo IS NULL OR mejor_tiempo > ?)";
        try (PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setLong(1, duration);
            pst.setString(2, username);
            pst.setLong(3, duration);
            int rowsUpdated = pst.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Mejor tiempo actualizado para el usuario: " + username + " - Tiempo: " + duration + " ms");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void showRanking() {
        System.out.println("\nRanking de Jugadores:");
        Collections.sort(ranking);  // Ordena a los jugadores por el tiempo
        for (int i = 0; i < ranking.size(); i++) {
            Jugador jugador = ranking.get(i);
            System.out.println((i + 1) + ". " + jugador.getUsername() + " - " + jugador.getMejorTiempo() + " ms");
        }
    }

    static class ClientHandler extends Thread {
        private final Socket socket;
        private final PrintWriter out;
        private final BufferedReader in;
        private final String username;
        private int clicks;
        private long startTime;
        private final JFrame frame;

        public ClientHandler(Socket socket, PrintWriter out, BufferedReader in, String username, JFrame frame) {
            this.socket = socket;
            this.out = out;
            this.in = in;
            this.username = username;
            this.clicks = 0;
            this.startTime = 0;
            this.frame = frame;
        }

        @Override
        public void run() {
            try {
                String clientMessage;

                // Comienza el juego
                out.println("¡El juego ha comenzado!");
                startTime = System.currentTimeMillis(); // Registrar el tiempo al iniciar el juego

                while ((clientMessage = in.readLine()) != null) {
                    if ("Clic".equals(clientMessage)) {
                        clicks++;
                        System.out.println("Clic recibido de " + username + ". Total: " + clicks);

                        // Actualizar barra de progreso
                        int progress = (int) ((clicks / (float) MAX_CLICKS) * 100);
                        SwingUtilities.invokeLater(() -> progressBar.setValue(clicks));

                        out.println("Progreso: " + progress + "%");

                        if (clicks >= MAX_CLICKS) {
                            long endTime = System.currentTimeMillis();
                            long duration = endTime - startTime;
                            out.println("¡Ganaste! El tiempo total fue: " + duration + " milisegundos.");

                            // Actualizar el mejor tiempo en la base de datos
                            updateBestTime(username, duration);

                            // Agregar al ranking
                            ranking.add(new Jugador(username, duration));

                            // Mostrar el ranking
                            showRanking();

                            break;
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Clase Jugador para manejar el ranking
    static class Jugador implements Comparable<Jugador> {
        private final String username;
        private final long mejorTiempo;

        public Jugador(String username, long mejorTiempo) {
            this.username = username;
            this.mejorTiempo = mejorTiempo;
        }

        public String getUsername() {
            return username;
        }

        public long getMejorTiempo() {
            return mejorTiempo;
        }

        @Override
        public int compareTo(Jugador o) {
            return Long.compare(this.mejorTiempo, o.mejorTiempo);
        }
    }
}
